import json, os, uuid
from pathlib import Path
from typing import Any
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, WebSocket, WebSocketDisconnect, Form
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import select
from .database import Base, engine, get_db, SessionLocal
from .models import User, Conversation, Message, conversation_members
from .schemas import RegisterIn, UserOut, TokenOut, ConversationCreate, ConversationOut, MessageCreate, MessageOut
from .auth import hash_password, verify_password, create_token, current_user, get_user_from_token

Base.metadata.create_all(bind=engine)
app = FastAPI(title="Massenger T API", version="0.1.0")
origins = [x.strip() for x in os.getenv("CORS_ORIGINS", "*").split(",")]
app.add_middleware(CORSMiddleware, allow_origins=origins if origins != ["*"] else ["*"],
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
MEDIA_DIR = Path(os.getenv("MEDIA_DIR", "./media"))
MEDIA_DIR.mkdir(parents=True, exist_ok=True)

class ConnectionManager:
    def __init__(self):
        self.connections: dict[int, set[WebSocket]] = {}
    async def connect(self, user_id: int, ws: WebSocket):
        await ws.accept()
        self.connections.setdefault(user_id, set()).add(ws)
    def disconnect(self, user_id: int, ws: WebSocket):
        self.connections.get(user_id, set()).discard(ws)
    async def send_user(self, user_id: int, data: dict[str, Any]):
        for ws in list(self.connections.get(user_id, set())):
            try: await ws.send_json(data)
            except Exception: self.disconnect(user_id, ws)
    async def broadcast(self, user_ids: list[int], data: dict[str, Any]):
        for uid in set(user_ids): await self.send_user(uid, data)

manager = ConnectionManager()

@app.get("/health")
def health():
    return {"status": "ok", "service": "Massenger T API"}

@app.post("/auth/register", response_model=TokenOut)
def register(payload: RegisterIn, db: Session = Depends(get_db)):
    email = payload.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, "Email already registered")
    user = User(email=email, display_name=payload.display_name.strip(), password_hash=hash_password(payload.password))
    db.add(user); db.commit(); db.refresh(user)
    return {"access_token": create_token(user.id), "user": user}

@app.post("/auth/login", response_model=TokenOut)
def login(username: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == username.lower()))
    if not user or not verify_password(password, user.password_hash):
        raise HTTPException(401, "Incorrect email or password")
    return {"access_token": create_token(user.id), "user": user}

@app.get("/me", response_model=UserOut)
def me(user: User = Depends(current_user)):
    return user

@app.get("/users", response_model=list[UserOut])
def users(q: str = "", db: Session = Depends(get_db), user: User = Depends(current_user)):
    stmt = select(User).where(User.id != user.id)
    if q: stmt = stmt.where(User.display_name.ilike(f"%{q[:80]}%"))
    return list(db.scalars(stmt.limit(50)).all())

def require_member(db: Session, conversation_id: int, user_id: int) -> Conversation:
    conv = db.get(Conversation, conversation_id)
    if not conv or not db.execute(select(conversation_members).where(
        conversation_members.c.conversation_id == conversation_id,
        conversation_members.c.user_id == user_id)).first():
        raise HTTPException(404, "Conversation not found")
    return conv

@app.post("/conversations", response_model=ConversationOut)
def create_conversation(payload: ConversationCreate, db: Session = Depends(get_db), user: User = Depends(current_user)):
    conv = Conversation(title=payload.title or ("Direct chat" if payload.kind == "direct" else "New " + payload.kind),
                        kind=payload.kind, created_by=user.id)
    ids = set(payload.member_ids + [user.id])
    members = list(db.scalars(select(User).where(User.id.in_(ids))).all())
    if len(members) != len(ids): raise HTTPException(400, "One or more users do not exist")
    conv.members = members
    db.add(conv); db.commit(); db.refresh(conv)
    return conv

@app.get("/conversations", response_model=list[ConversationOut])
def list_conversations(db: Session = Depends(get_db), user: User = Depends(current_user)):
    return list(db.scalars(select(Conversation).join(conversation_members).where(
        conversation_members.c.user_id == user.id).order_by(Conversation.created_at.desc())).unique().all())

@app.get("/conversations/{conversation_id}/messages", response_model=list[MessageOut])
def history(conversation_id: int, limit: int = 50, db: Session = Depends(get_db), user: User = Depends(current_user)):
    require_member(db, conversation_id, user.id)
    rows = list(db.scalars(select(Message).where(Message.conversation_id == conversation_id)
                           .order_by(Message.id.desc()).limit(max(1, min(limit, 100))).all()))
    return list(reversed(rows))

@app.post("/conversations/{conversation_id}/messages", response_model=MessageOut)
async def send_message(conversation_id: int, payload: MessageCreate, db: Session = Depends(get_db), user: User = Depends(current_user)):
    conv = require_member(db, conversation_id, user.id)
    msg = Message(conversation_id=conversation_id, sender_id=user.id, body=payload.body)
    db.add(msg); db.commit(); db.refresh(msg)
    event = {"type":"message", "message": MessageOut.model_validate(msg).model_dump(mode="json")}
    await manager.broadcast([m.id for m in conv.members], event)
    return msg

@app.post("/media")
async def upload_media(file: UploadFile = File(...), user: User = Depends(current_user)):
    # Development-only upload. Add size limits, MIME sniffing, malware scanning, and private access controls before production.
    safe_name = f"{uuid.uuid4().hex}_{Path(file.filename or 'upload.bin').name}"
    dest = MEDIA_DIR / safe_name
    total = 0
    with dest.open("wb") as out:
        while chunk := await file.read(1024 * 1024):
            total += len(chunk)
            if total > 50 * 1024 * 1024:
                out.close(); dest.unlink(missing_ok=True)
                raise HTTPException(413, "File too large (50 MB limit)")
            out.write(chunk)
    return {"filename": safe_name, "size": total, "content_type": file.content_type, "note":"Development storage only; configure authenticated downloads."}

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket, token: str):
    db = SessionLocal()
    try:
        try: user = get_user_from_token(token, db)
        except HTTPException:
            await ws.close(code=1008); return
        await manager.connect(user.id, ws)
        await ws.send_json({"type":"connected", "user_id":user.id})
        while True:
            event = await ws.receive_json()
            if not isinstance(event, dict): continue
            if event.get("type") == "message":
                conv_id = int(event.get("conversation_id", 0))
                conv = db.get(Conversation, conv_id)
                member = db.execute(select(conversation_members).where(
                    conversation_members.c.conversation_id == conv_id,
                    conversation_members.c.user_id == user.id)).first()
                body = str(event.get("body", "")).strip()
                if not conv or not member or not body or len(body) > 10000:
                    await ws.send_json({"type":"error","detail":"Invalid conversation or message"}); continue
                msg = Message(conversation_id=conv_id, sender_id=user.id, body=body)
                db.add(msg); db.commit(); db.refresh(msg)
                await manager.broadcast([m.id for m in conv.members], {
                    "type":"message", "message":MessageOut.model_validate(msg).model_dump(mode="json")})
            elif event.get("type") == "call_signal":
                # Production must verify the sender and target share this conversation.
                target = int(event.get("target_user_id", 0))
                await manager.send_user(target, {"type":"call_signal","from_user_id":user.id,
                    "conversation_id":event.get("conversation_id"),"signal":event.get("signal", {})})
            else:
                await ws.send_json({"type":"error","detail":"Unknown event type"})
    except WebSocketDisconnect:
        pass
    except Exception:
        try: await ws.close(code=1011)
        except Exception: pass
    finally:
        if 'user' in locals(): manager.disconnect(user.id, ws)
        db.close()
