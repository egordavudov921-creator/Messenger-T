from datetime import datetime
from typing import Literal
from pydantic import BaseModel, EmailStr, Field

class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    display_name: str = Field(min_length=1, max_length=80)

class UserOut(BaseModel):
    id: int
    email: EmailStr
    display_name: str
    model_config = {"from_attributes": True}

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut

class ConversationCreate(BaseModel):
    title: str = Field(default="", max_length=120)
    kind: Literal["direct", "group", "channel"] = "group"
    member_ids: list[int] = []

class ConversationOut(BaseModel):
    id: int
    title: str
    kind: str
    created_by: int
    model_config = {"from_attributes": True}

class MessageCreate(BaseModel):
    body: str = Field(min_length=1, max_length=10000)

class MessageOut(BaseModel):
    id: int
    conversation_id: int
    sender_id: int
    body: str
    created_at: datetime
    model_config = {"from_attributes": True}
