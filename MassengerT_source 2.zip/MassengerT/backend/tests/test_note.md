Add automated tests before deployment: registration/login, authorization, membership isolation, message persistence, upload limits, websocket reconnects, and call-signal authorization.
