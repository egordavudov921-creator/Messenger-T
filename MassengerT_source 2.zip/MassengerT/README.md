# Massenger T — cross-platform messenger starter

Starter repository for an Android/iOS messenger with a Flutter client and FastAPI backend.

## Included
- Email/password registration and login (bcrypt password hashing, JWT access tokens)
- PostgreSQL in Docker; SQLite fallback for local backend development
- REST API for conversations, memberships, message history, and media uploads
- WebSocket live messaging and WebRTC signaling relay for voice/video call prototypes
- Direct, group, and channel conversation types
- Flutter starter UI for login, conversation list, and live text chat

## Important scope and security notes
This is a runnable **development MVP**, not a production-ready Telegram replacement. The WebSocket server currently broadcasts events to connected clients; before public deployment, add per-conversation authorization to every event, rate limiting, abuse reporting, push notifications, migrations, monitoring, backups, and security review.
The WebRTC signaling endpoint only relays offer/answer/ICE messages. It does not itself provide STUN/TURN infrastructure or guarantee calls work across NATs. Configure a TURN server for production.
Transport security must use HTTPS/WSS behind a reverse proxy. Uploaded files are stored locally in development; use private object storage and signed URLs in production.
**End-to-end encryption is not implemented in this starter.** TLS protects traffic in transit, but the server can read message content. Do not advertise E2EE until a reviewed protocol, device key management, identity verification, key rotation, and multi-device recovery are implemented and independently audited.

## Run the backend
Requirements: Python 3.11+

```bash
cd backend
python -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

API docs: http://127.0.0.1:8000/docs

For PostgreSQL instead:
```bash
docker compose up --build
```
Backend runs on port 8000. Set `DATABASE_URL` in `backend/.env` to
`postgresql+psycopg://massengert:change-me@localhost:5432/massengert`.

## Run the Flutter client
Install Flutter stable and Android Studio / Xcode as appropriate.

```bash
cd mobile
flutter pub get
flutter run
```

The sample client defaults to `http://10.0.2.2:8000` for Android Emulator.
- Android emulator: `10.0.2.2`
- iOS Simulator: `127.0.0.1`
- Physical phone: replace the API base URL in `mobile/lib/main.dart` with your computer's LAN IP and ensure both devices share a network.
For production, use an HTTPS domain.

## Build
```bash
# Android APK
cd mobile
flutter build apk --release

# Android App Bundle for Google Play
flutter build appbundle --release

# iOS (requires macOS + Xcode)
flutter build ios --release
```
iOS signing and App Store submission require your Apple Developer account. This archive is source code, not a prebuilt signed APK/IPA.

## API outline
- `POST /auth/register` `{ "email": "...", "password": "...", "display_name": "..." }`
- `POST /auth/login` form fields `username` (email), `password`
- `GET /me` with `Authorization: Bearer <token>`
- `POST /conversations` `{ "title": "...", "kind": "direct|group|channel", "member_ids": [2,3] }`
- `GET /conversations`
- `GET /conversations/{id}/messages`
- `POST /conversations/{id}/messages` `{ "body": "..." }`
- `POST /media` multipart upload
- `WS /ws?token=<JWT>` live message and call-signaling event stream

WebSocket client events:
```json
{"type":"message","conversation_id":1,"body":"Hello"}
{"type":"call_signal","conversation_id":1,"target_user_id":2,"signal":{"type":"offer","sdp":"..."}}
```
Server messages include `type: message`, `type: call_signal`, and `type: error`.


## Two-phone chat smoke test
1. Start the backend on a computer reachable from both phones.
2. Find that computer's LAN IP address (for example `192.168.1.20`) and set the Flutter API base URL:
   `flutter run --dart-define=API_BASE=http://192.168.1.20:8000`
3. For local HTTP development, Android may require cleartext traffic enabled in the debug manifest; iOS Simulator can use `127.0.0.1`, but physical phones need the computer's LAN IP. Production must use HTTPS/WSS.
4. Register account A on phone A and account B on phone B.
5. On phone A, tap **Новый чат**, choose account B, then send a message. The WebSocket event should appear on both devices.
6. On phone B, go back to the chat list and open the conversation to check stored message history.

This MVP creates a new direct conversation each time the user starts one; add direct-chat deduplication before production. Run two clients against one shared server/database to test delivery.
