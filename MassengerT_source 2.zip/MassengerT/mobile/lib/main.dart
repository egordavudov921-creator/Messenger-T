import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

const apiBase = String.fromEnvironment(
  'API_BASE',
  defaultValue: 'http://10.0.2.2:8000',
);

void main() => runApp(const MassengerTApp());

class MassengerTApp extends StatelessWidget {
  const MassengerTApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Massenger T',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6659F0)),
          useMaterial3: true,
          scaffoldBackgroundColor: const Color(0xFFF7F7FC),
        ),
        home: const BootstrapScreen(),
      );
}

class Api {
  String? token;
  Map<String, String> get headers => {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  Future<dynamic> request(String path,
      {String method = 'GET', Object? body}) async {
    final uri = Uri.parse('$apiBase$path');
    final res = method == 'POST'
        ? await http.post(uri, headers: headers, body: body == null ? null : jsonEncode(body))
        : await http.get(uri, headers: headers);
    final dynamic data = res.body.isEmpty ? <String, dynamic>{} : jsonDecode(res.body);
    if (res.statusCode >= 400) {
      final detail = data is Map ? data['detail'] : null;
      throw Exception(detail ?? 'Request failed (${res.statusCode})');
    }
    return data;
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    final res = await http.post(
      Uri.parse('$apiBase/auth/login'),
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: {'username': email, 'password': password},
    );
    final data = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode >= 400) throw Exception(data['detail'] ?? 'Login failed');
    return data;
  }
}

final api = Api();

class BootstrapScreen extends StatefulWidget {
  const BootstrapScreen({super.key});
  @override
  State<BootstrapScreen> createState() => _BootstrapScreenState();
}
class _BootstrapScreenState extends State<BootstrapScreen> {
  @override
  void initState() {
    super.initState();
    _restore();
  }
  Future<void> _restore() async {
    final prefs = await SharedPreferences.getInstance();
    api.token = prefs.getString('token');
    if (!mounted) return;
    if (api.token != null) {
      try {
        await api.request('/me');
        if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const ChatsScreen()));
        return;
      } catch (_) {
        await prefs.remove('token');
        api.token = null;
      }
    }
    if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AuthScreen()));
  }
  @override
  Widget build(BuildContext context) => const Scaffold(body: Center(child: CircularProgressIndicator()));
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}
class _AuthScreenState extends State<AuthScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  final name = TextEditingController();
  bool register = false, busy = false;
  String? error;

  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      Map<String, dynamic> data;
      if (register) {
        data = await api.request('/auth/register', method: 'POST', body: {
          'email': email.text.trim(),
          'password': password.text,
          'display_name': name.text.trim(),
        }) as Map<String, dynamic>;
      } else {
        data = await api.login(email.text.trim(), password.text);
      }
      api.token = data['access_token'] as String;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('token', api.token!);
      if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const ChatsScreen()));
    } catch (e) {
      setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() { email.dispose(); password.dispose(); name.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 420),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(width: 76, height: 76, alignment: Alignment.center,
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF6659F0), Color(0xFF9B72F2)]), borderRadius: BorderRadius.circular(24)),
            child: const Icon(Icons.forum_rounded, color: Colors.white, size: 38)),
          const SizedBox(height: 24),
          const Text('Massenger T', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800)),
          const Text('Общение без границ', style: TextStyle(color: Colors.black54)),
          const SizedBox(height: 28),
          if (register) ...[
            TextField(controller: name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Имя', border: OutlineInputBorder())),
            const SizedBox(height: 12),
          ],
          TextField(controller: email, keyboardType: TextInputType.emailAddress, autocorrect: false, decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Пароль (минимум 8 символов)', border: OutlineInputBorder())),
          if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: Colors.red))),
          const SizedBox(height: 20),
          FilledButton(onPressed: busy ? null : submit, child: Text(busy ? 'Подождите…' : register ? 'Создать аккаунт' : 'Войти')),
          TextButton(onPressed: () => setState(() { register = !register; error = null; }), child: Text(register ? 'Уже есть аккаунт? Войти' : 'Создать новый аккаунт')),
        ]),
      ),
    )),
  );
}

class ChatsScreen extends StatefulWidget {
  const ChatsScreen({super.key});
  @override
  State<ChatsScreen> createState() => _ChatsScreenState();
}
class _ChatsScreenState extends State<ChatsScreen> {
  List<dynamic> chats = [];
  bool loading = true;
  String? error;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final result = await api.request('/conversations');
      setState(() => chats = result as List<dynamic>);
    } catch (e) { setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => loading = false); }
  }

  Future<void> openUsers() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => const UsersScreen()));
    load();
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
    api.token = null;
    if (mounted) Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const AuthScreen()), (_) => false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Massenger T', style: TextStyle(fontWeight: FontWeight.w800)),
      actions: [
        IconButton(onPressed: load, tooltip: 'Обновить', icon: const Icon(Icons.refresh)),
        IconButton(onPressed: openUsers, tooltip: 'Найти пользователя', icon: const Icon(Icons.person_add_alt_1)),
        IconButton(onPressed: logout, tooltip: 'Выйти', icon: const Icon(Icons.logout)),
      ]),
    body: loading ? const Center(child: CircularProgressIndicator())
      : error != null ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(error!, textAlign: TextAlign.center)))
      : chats.isEmpty ? const Center(child: Text('Пока нет чатов.\nНажми на значок человека, чтобы найти собеседника.', textAlign: TextAlign.center))
      : RefreshIndicator(onRefresh: load, child: ListView.separated(
          itemCount: chats.length, separatorBuilder: (_, __) => const Divider(height: 1, indent: 76),
          itemBuilder: (ctx, i) {
            final c = chats[i] as Map<String, dynamic>;
            return ListTile(
              leading: CircleAvatar(backgroundColor: const Color(0xFFE8E5FF), child: Icon(c['kind'] == 'channel' ? Icons.campaign : Icons.forum, color: const Color(0xFF6659F0))),
              title: Text((c['title'] as String?)?.isNotEmpty == true ? c['title'] : 'Чат #${c['id']}', style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(c['kind'] ?? 'group'),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(id: c['id'] as int, title: (c['title'] as String?)?.isNotEmpty == true ? c['title'] : 'Чат #${c['id']}'))),
            );
          },
        )),
    floatingActionButton: FloatingActionButton.extended(onPressed: openUsers, icon: const Icon(Icons.edit), label: const Text('Новый чат')),
  );
}

class UsersScreen extends StatefulWidget {
  const UsersScreen({super.key});
  @override
  State<UsersScreen> createState() => _UsersScreenState();
}
class _UsersScreenState extends State<UsersScreen> {
  final search = TextEditingController();
  List<dynamic> users = [];
  bool loading = false;
  String? error;

  Future<void> load() async {
    setState(() { loading = true; error = null; });
    try {
      final q = Uri.encodeQueryComponent(search.text.trim());
      final result = await api.request('/users${q.isEmpty ? '' : '?q=$q'}');
      setState(() => users = result as List<dynamic>);
    } catch (e) { setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => loading = false); }
  }

  Future<void> startChat(Map<String, dynamic> person) async {
    try {
      final conv = await api.request('/conversations', method: 'POST', body: {
        'title': person['display_name'],
        'kind': 'direct',
        'member_ids': [person['id']],
      }) as Map<String, dynamic>;
      if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ChatScreen(id: conv['id'] as int, title: person['display_name'] as String)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  @override
  void initState() { super.initState(); load(); }
  @override
  void dispose() { search.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Найти пользователя')),
    body: Column(children: [
      Padding(padding: const EdgeInsets.all(16), child: TextField(
        controller: search, onSubmitted: (_) => load(),
        decoration: InputDecoration(hintText: 'Поиск по имени', prefixIcon: const Icon(Icons.search),
          suffixIcon: IconButton(onPressed: load, icon: const Icon(Icons.arrow_forward)),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
      )),
      if (loading) const LinearProgressIndicator(),
      if (error != null) Padding(padding: const EdgeInsets.all(16), child: Text(error!, style: const TextStyle(color: Colors.red))),
      Expanded(child: users.isEmpty && !loading
        ? const Center(child: Text('Пользователи не найдены'))
        : ListView.separated(itemCount: users.length, separatorBuilder: (_, __) => const Divider(height: 1, indent: 72),
            itemBuilder: (ctx, i) {
              final u = users[i] as Map<String, dynamic>;
              return ListTile(
                leading: CircleAvatar(child: Text((u['display_name'] as String).isNotEmpty ? (u['display_name'] as String)[0].toUpperCase() : '?')),
                title: Text(u['display_name'] ?? 'Пользователь'),
                subtitle: Text(u['email'] ?? ''),
                trailing: const Icon(Icons.chat_bubble_outline),
                onTap: () => startChat(u),
              );
            })),
    ]),
  );
}

class ChatScreen extends StatefulWidget {
  final int id;
  final String title;
  const ChatScreen({super.key, required this.id, required this.title});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}
class _ChatScreenState extends State<ChatScreen> {
  final input = TextEditingController();
  final scroll = ScrollController();
  final List<Map<String, dynamic>> messages = [];
  WebSocketChannel? channel;
  StreamSubscription? sub;
  bool socketReady = false, loading = true, sending = false;
  String? error;

  @override
  void initState() { super.initState(); loadHistory(); connect(); }

  Future<void> loadHistory() async {
    try {
      final result = await api.request('/conversations/${widget.id}/messages') as List<dynamic>;
      if (!mounted) return;
      setState(() {
        messages.clear();
        messages.addAll(result.cast<Map<String, dynamic>>());
      });
      _scrollBottom();
    } catch (e) { if (mounted) setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => loading = false); }
  }

  void connect() {
    final wsBase = apiBase.replaceFirst('https://', 'wss://').replaceFirst('http://', 'ws://');
    try {
      channel = WebSocketChannel.connect(Uri.parse('$wsBase/ws?token=${Uri.encodeQueryComponent(api.token!)}'));
      sub = channel!.stream.listen((raw) {
        final event = jsonDecode(raw as String) as Map<String, dynamic>;
        if (event['type'] == 'connected') {
          if (mounted) setState(() => socketReady = true);
        } else if (event['type'] == 'message') {
          final m = Map<String, dynamic>.from(event['message'] as Map);
          if (m['conversation_id'] == widget.id && mounted) {
            setState(() {
              if (!messages.any((existing) => existing['id'] == m['id'])) messages.add(m);
            });
            _scrollBottom();
          }
        } else if (event['type'] == 'error' && mounted) {
          setState(() => error = event['detail']?.toString());
        }
      }, onError: (Object e) {
        if (mounted) setState(() { socketReady = false; error = 'Связь потеряна. Вернись в чат и попробуй снова.'; });
      }, onDone: () {
        if (mounted) setState(() => socketReady = false);
      });
    } catch (_) {
      setState(() { socketReady = false; error = 'Не удалось подключиться к серверу сообщений'; });
    }
  }

  void _scrollBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) scroll.animateTo(scroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 180), curve: Curves.easeOut);
    });
  }

  void send() {
    final text = input.text.trim();
    if (text.isEmpty || !socketReady || channel == null) return;
    channel!.sink.add(jsonEncode({'type': 'message', 'conversation_id': widget.id, 'body': text}));
    input.clear();
  }

  @override
  void dispose() {
    sub?.cancel(); channel?.sink.close(); input.dispose(); scroll.dispose(); super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.title), actions: [
      Padding(padding: const EdgeInsets.only(right: 16), child: Icon(socketReady ? Icons.cloud_done : Icons.cloud_off,
        color: socketReady ? Colors.green : Colors.orange)),
    ]),
    body: Column(children: [
      if (!socketReady) const LinearProgressIndicator(minHeight: 2),
      if (error != null) Material(color: const Color(0xFFFFE9E9), child: Padding(padding: const EdgeInsets.all(8), child: Text(error!, style: const TextStyle(color: Colors.red)))),
      Expanded(child: loading ? const Center(child: CircularProgressIndicator())
        : messages.isEmpty ? const Center(child: Text('Начни переписку 👋'))
        : ListView.builder(controller: scroll, padding: const EdgeInsets.all(16), itemCount: messages.length,
          itemBuilder: (ctx, i) {
            final m = messages[i];
            return Align(alignment: Alignment.centerLeft, child: Container(
              constraints: const BoxConstraints(maxWidth: 320),
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
              child: Text(m['body']?.toString() ?? ''),
            ));
          })),
      SafeArea(child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
        Expanded(child: TextField(controller: input, onSubmitted: (_) => send(), textInputAction: TextInputAction.send,
          decoration: InputDecoration(hintText: socketReady ? 'Сообщение…' : 'Подключение к серверу…',
            filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)))),
        const SizedBox(width: 8),
        IconButton.filled(onPressed: socketReady ? send : null, icon: const Icon(Icons.send_rounded)),
      ]))),
    ]),
  );
}
